//
//  ViewController.swift
//  Thukivakam_WordGuess
//
//  Created by Thukivakam,Sai Kiran on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var guessBut: UIButton!
    
    @IBOutlet weak var PABut: UIButton!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    var guess : String = ""
    var wordLevel : Int = 0
    var NoofWords = 0
    var remaining = 5
    var flg = false
    var ResetFlag = false
    var words = ""
    var guessed = 0
    let wrng = 10
    var image = [["delhi","Capital of India", "delhi"],["goa","A place where all tourists enjoy in beaches","goa"],["ramesh","A place where pamban bridge is located","ramesh"],["tirupati","place where balaji temple is","tirupati"],["vizag","the city of destiny","vizag"]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Rset()
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        guessed+=1
        if(guessed < wrng) {
            var InputText = guessLetterField.text!.last
            words = "\(words)\(InputText!)"
            var FormedString = ""
            for l in guess {
                if(words.uppercased().contains(l.uppercased())) {
                    FormedString+="\(l.uppercased())"
                }
                else {
                    FormedString+="_ "
                }
                
            }
            userGuessLabel.text = FormedString
            
            if(!userGuessLabel.text!.contains("_")) {
                NoofWords+=1
                remaining-=1
                guessCountLabel.text = "Wow! You have made \(guessed) guesses to guess the word!"
                wordsGuessedLabel.text = "Total Number of words guessed successfully: \(NoofWords)"
                wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
                totalWordsLabel.text = "Total number of words in game: 5"
               
                
                    displayImage.image = UIImage(named: image[wordLevel][2])
                   
                
                PABut.isHidden = false
                guessLetterField.text = ""
                guessBut.isEnabled = false
                
            }
            else {
                guessCountLabel.text = "You have made \(guessed) guesses"
                PABut.isHidden = true
            }
        }
        else {
            guessCountLabel.text = "You have used all the available guesses,Please play again"
            PABut.isHidden = false
            guessed=0
        }
    }
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        if(NoofWords==5 && remaining ==  0 && ResetFlag==false) {
            statusLabel.text="Congratulations! You are done with the game! Please start over again"
            displayImage.image = UIImage(named: "All")
            flg = true
        }
        
        if(flg==false) {
            
            if(!userGuessLabel.text!.contains("_")) {
                guessed = 0
                wordLevel+=1
                words=""
                guess = image[wordLevel][0]
                hintLabel.text = "Hint: \(image[wordLevel][1])"
                var i = 0
                var str = ""
                
                while(i<guess.count) {
                    str = "\(str) _ "
                    i=i+1
                }
                userGuessLabel.text = str
                statusLabel.text = ""
                PABut.isHidden = true
                guessLetterField.text=""
            }
            else {
                PABut.isHidden=true
            }
            displayImage.image=UIImage(named: "")
        }
        else {
            if(ResetFlag==true) {
                Rset()
            }
            else {
                ResetFlag = true
            }
        }
    }
    
    @IBAction func CharactersEntered(_ sender: Any) {
        if(guessLetterField.text!.isEmpty) {
            guessBut.isEnabled = false
        }
        else {
            guessBut.isEnabled = true
        }
    }
    
    
    
    func Rset() {
        wordLevel = 0
        words = ""
        guessed = 0
        flg = false
        ResetFlag = false
        guessLetterField.text=""
        PABut.isHidden=true
        guess = image[wordLevel][0]
        // Do any additional setup after loading the view.
        wordsGuessedLabel.text = "Total Number of words guessed successfully: 0"
        wordsRemainingLabel.text = "Total number of words remaining in game: 5"
        totalWordsLabel.text = "Total number of words in game: 5"
        guessBut.isEnabled = false
        var firstWord = image[wordLevel][0]
        hintLabel.text = "Hint: \(image[wordLevel][1])"
        var i = 0
        var str = ""
        
        while(i<firstWord.count) {
            str = "\(str) _ "
            i=i+1
        }
        userGuessLabel.text = str
        statusLabel.text = ""
        guessCountLabel.text = "You have made \(guessed) guesses"
        displayImage.image = UIImage(named: "")
        NoofWords = 0
        remaining = 5
        
    }
    
}

