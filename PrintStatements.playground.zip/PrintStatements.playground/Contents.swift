import UIKit

var greeting = "Hello, playground"
var i = 10
//comma is separated by space.
print("Hello",1.0,2)
//String interpolation. Also should have consistent space for = on both sides
var name = "Sai"
print("Hi \(name)!")
//alternate way of writing the print statement with string interpolation it works only with strings
print("Hello "+name+"!")
//multiplication in orint
print("age is \(i*2)")
//more quotes but maintain the same format
print("""
hi
will this come in new line
""")
//carriage return
print("hello\rit prints in the new lnine from here😆")
///when using the let keyowrd the value canot be changed
let  welcomeMessage : String = "Hello!"
print(welcomeMessage , "All")

//terminator means telling the compiler to join the next line
print("Welcome to Swift Programming")
print("Fall 2021")
print("*************")
print("Welcome to Swift Programming" , terminator : "-" )
print("Fall 2021")
//this separator used as concat in js kind
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
