//
//  ResultViewController.swift
//  MultiViewControllerHome
//
//  Created by Karuturi,Sri Tarun on 4/3/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var result: UILabel!
    
    var theFinalRes=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        result.text=theFinalRes
    }
    

}
