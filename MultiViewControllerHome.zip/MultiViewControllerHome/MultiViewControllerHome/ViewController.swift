//
//  ViewController.swift
//  MultiViewControllerHome
//
//  Created by Karuturi,Sri Tarun on 4/3/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var textFieldOL: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func checkBTN(_ sender: Any) {
        
        var newText=textFieldOL.text!
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition=="resultSegue"{
            var destination = segue.destination as! ResultViewController
            destination.theFinalRes=textFieldOL.text!
        }
    }
}

