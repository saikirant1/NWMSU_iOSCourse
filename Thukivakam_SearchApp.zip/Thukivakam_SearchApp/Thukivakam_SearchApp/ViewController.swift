//
//  ViewController.swift
//  Thukivakam_SearchApp
//
//  Created by Thukivakam,Sai Kiran on 3/23/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchOut: UIButton!
    
    
    @IBOutlet weak var prevOut: UIButton!
    
    
    @IBOutlet weak var NextOut: UIButton!
    
    
    @IBOutlet weak var resetOut: UIButton!
    
    
    var ars = [["biryani","chapati","noodles","dosa","idly"],["cat","lion","zebra","tiger","elephant"],["vizag","tirupati","goa","delhi","ramesh"]]
    var animals_keys=["animals","animal","wild"]
    var food_keys=["foods","dishes","food"]
    var place_keys=["place","places","tourist"]
    
    
    
    var topics_array = [["Biryani is a mixed rice dish originating among the Muslims of the Indian subcontinent","Chapati, also known as roti, rooti, rotli, rotta, safati, shabaati, phulka, chapo, poli, and roshi, is an unleavened flatbread originating from the Indian","Noodles are a type of food made from unleavened dough which is either rolled flat and cut, stretched, or extruded, into long strips or strings","A dose, also called dosai, dosey, dwashi or dosha is a thin pancake in South Indian cuisine","Idli or idly is a type of savoury rice cake, originating from South India"],["The cat is a domestic species of small carnivorous mammal.","The lion is a large cat of the genus Panthera native to Africa and India.","Zebras are African equines with distinctive black-and-white striped coats","The tiger is the largest living cat species and a member of the genus Panthera","Elephants are the largest existing land animals. Three living species are currently recognised"],["Visakhapatnam is a port city and industrial center in the Indian state of Andhra Pradesh","Tirupati is a city in the Indian state of Andhra Pradesh. Its Sri Venkateswara Temple","Goa is a state in western India with coastlines stretching along the Arabian Sea","Delhi, India’s capital territory, is a massive metropolitan area in the country’s north","Rameswaram is a town on Pamban Island, in the southeast Indian state of Tamil Nadu"]]
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        RfrshFlds()
    }
    
    var imageNum : Int = 0
    var tc : Int = 0



    @IBAction func searchButtonAction(_ sender: Any) {
        
        var inpu = searchTextField.text!.lowercased()
        
        if(food_keys.contains(inpu)) {
            tc = 1
        }
        else if(animals_keys.contains(inpu)) {
            tc = 2
        }
        else if(place_keys.contains(inpu)) {
            tc = 3
        }
        else {
            tc = 0
        }
        if(tc > 0) {
            imageNum = 0
            resultImage.image = UIImage(named: ars[tc-1][0])
            topicInfoText.text = topics_array[tc-1][0]
            prevOut.isHidden = false
            resetOut.isHidden = false
            NextOut.isHidden = false
            prevOut.isEnabled = false
            NextOut.isEnabled = true
            topicInfoText.isHidden = false
        }
        else {
            imageNum = 0
            resultImage.image = UIImage(named: "notfound")
            
            prevOut.isHidden = true
            resetOut.isHidden = true
            NextOut.isHidden = true
            topicInfoText.isHidden = true
            
        }

    }
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        imageNum = imageNum+1
                resultImage.image = UIImage(named: ars[tc-1][imageNum])
        topicInfoText.text = topics_array[tc-1][imageNum]
        prevOut.isHidden = false;
        resetOut.isHidden = false
        NextOut.isHidden=false
        prevOut.isEnabled = true
        if(imageNum==4) {
            NextOut.isEnabled = false
            
        }

    }
    
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        imageNum=imageNum-1
        resultImage.image = UIImage(named: ars[tc-1][imageNum])
        topicInfoText.text = topics_array[tc-1][imageNum]
        NextOut.isEnabled = true
        prevOut.isHidden = false;
        resetOut.isHidden = false
        NextOut.isHidden=false
        if(imageNum==0) {
            prevOut.isEnabled = false
        }

    }
    
    @IBAction func ResetBtn(_ sender: Any) {
        
        RfrshFlds()

    }
    
    func RfrshFlds() {
       imageNum = 0;
       tc = 0;
        prevOut.isHidden = true
        resetOut.isHidden = true
        NextOut.isHidden = true
        searchTextField.text = ""
        searchOut.isEnabled = false
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.isHidden = true

    }
        
    
    
    @IBAction func SearchStringEntered(_ sender: Any) {
        
        if(searchTextField.text!.isEmpty) {
            searchOut.isEnabled = false
        }
        else {
            searchOut.isEnabled = true
        }
        
    }
    
}

