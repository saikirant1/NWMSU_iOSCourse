import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var bmiLabel: UILabel!
    @IBOutlet weak var bmiImageView: UIImageView!
    
    var bmi: Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let bmi = bmi {
            bmiLabel.text = String(format: "Your BMI is %.1f", bmi)
            setBMIImage(bmi: bmi)
        }
    }
    
    @IBAction func backButtonTapped(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    func setBMIImage(bmi: Double) {
        var imageName = ""
        
        switch bmi {
        case ..<18.5:
            imageName = "underweight"
        case 18.5..<25:
            imageName = "normal"
        case 25..<30:
            imageName = "overweight"
        default:
            imageName = "obese"
        }
        
        bmiImageView.image = UIImage(named: imageName)
    }
}
