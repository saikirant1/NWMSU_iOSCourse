import UIKit

class FirstViewController: UIViewController {
    
    @IBOutlet weak var heightTextField: UITextField!
    @IBOutlet weak var weightTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func calculateButtonTapped(_ sender: Any) {
        guard let height = Double(heightTextField.text ?? ""), let weight = Double(weightTextField.text ?? "") else {
            return
            
        }
        
        let bmi = calculateBMI(height: height, weight: weight)
        navigateToSecondScreen(bmi: bmi)
    }
    
    
    
    func calculateBMI(height: Double, weight: Double) -> Double {
        let heightMeters = height / 100
        return weight / (heightMeters * heightMeters)
    }
    
    func navigateToSecondScreen(bmi: Double) {
        
    }
}
