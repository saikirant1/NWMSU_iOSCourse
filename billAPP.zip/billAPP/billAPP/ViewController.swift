//
//  ViewController.swift
//  billAPP
//
//  Created by Thukivakam,Sai Kiran on 2/28/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var productNameTextField: UITextField!
    
    
    @IBOutlet weak var numberOfUnitsTextField: UITextField!
    
    
    @IBOutlet weak var totalPriceBeforeDiscountLabel: UILabel!
    
    
    @IBOutlet weak var totalPriceAfterDiscountLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func calculateButtonPressed(_ sender: Any) {
        let productName = productNameTextField.text!
                let numberOfUnits = Int(numberOfUnitsTextField.text!)!
                
                var pricePerItem: Double = 0
                var discountRate: Double = 0
                
                switch productName {
                case "Perfume":
                    pricePerItem = 10
                    discountRate = 0.02
                case "T-Shirt":
                    pricePerItem = 35
                    discountRate = 0.04
                default:
                    pricePerItem = 0
                    discountRate = 0
                }
                
                let totalPriceBeforeDiscount = pricePerItem * Double(numberOfUnits)
                let totalPriceAfterDiscount = totalPriceBeforeDiscount * (1 - discountRate)
                
                totalPriceBeforeDiscountLabel.text = "$\(totalPriceBeforeDiscount)"
                totalPriceAfterDiscountLabel.text = "$\(totalPriceAfterDiscount)"
            }
        
    }
    


