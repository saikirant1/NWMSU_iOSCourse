//
//  ViewController.swift
//  TemperatureCheck
//
//  Created by Thukivakam,Sai Kiran on 2/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var enterValue: UITextField!
    
    @IBOutlet weak var imageOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func clickButton(_ sender: Any) {
        if let temperature = Int(enterValue.text ?? ""), temperature > 0 {
                    // Display sunny image
                    let sunnyImage = UIImage(named: "sun")
                    imageOL.image = sunnyImage
                } else {
                    // Display cold image
                    let coldImage = UIImage(named: "cold")
                    imageOL.image = coldImage
                }
    }
}

