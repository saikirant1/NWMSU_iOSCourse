//
//  ViewController.swift
//  Thukivakam_Assignment01
//
//  Created by Thukivakam,Sai Kiran on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    //firstNameOutlet
    @IBOutlet weak var firstNameOutlet: UITextField!
    
    //secondNameOutlet
    @IBOutlet weak var lastNameOutlet: UITextField!
    
    //yearOutlet
    @IBOutlet weak var yearOutlet: UITextField!
    //fullNameLabel
    @IBOutlet weak var fullNameLabel: UILabel!
    //initialsLabel
    @IBOutlet weak var initialsLabel: UILabel!
    //ageLabel
    @IBOutlet weak var ageLabel: UILabel!
    //details label
    @IBOutlet weak var detailsLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = UIColor.systemMint
    }
    //this button performs the actions as neede when the user clicks on submit
    @IBAction func SubmitBTN(_ sender: UIButton) {
        detailsLabel.text = "Details"
        //to print the full anme
        let fsname=firstNameOutlet.text!
        let lsname=lastNameOutlet.text!
        let fullnameis=lsname+" "+fsname
        fullNameLabel.text="Full Name : \(fullnameis)"
        
        //to print the initials
        let firstInitalentered = firstNameOutlet.text!
        let lastInitialentered = lastNameOutlet.text!
        let firstInitial1 = firstInitalentered[firstInitalentered.startIndex]
        let lastInitial2 = lastInitialentered[lastInitialentered.startIndex]
        let initials = String(lastInitial2) + " " + String(firstInitial1)
        initialsLabel.text = "Initials : \(initials)"
        
        //to get the DOB
        let enteredYear = Int(yearOutlet.text!)!
        let curYear = Calendar.current.component(.year, from: Date())
        let age = curYear - enteredYear
        ageLabel.text = "Age: \(age)"
    }
    
    //this button clears all the values enetered by the user and keeps it ready to enter other values
    @IBAction func ResetBTN(_ sender: UIButton) {
    // Erase all details entered
        firstNameOutlet.text = ""
        lastNameOutlet.text=""
        yearOutlet.text=""
    // Erase details displayed in a label
        fullNameLabel.text = ""
        initialsLabel.text=""
        ageLabel.text=""
        detailsLabel.text=""
    }
}

