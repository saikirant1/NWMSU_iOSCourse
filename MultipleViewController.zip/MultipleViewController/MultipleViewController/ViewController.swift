//
//  ViewController.swift
//  MultipleViewController
//
//  Created by Thukivakam,Sai Kiran on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var amountOL: UITextField!
    
    @IBOutlet weak var discrateOL: UITextField!
    var priceAfterDiscount=0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func calculate(_ sender: Any) {
        var amount=Double(amountOL.text!)
        //print(amount!)
        var discrate=Double(discrateOL.text!)
        //print(discrate!)
        
        priceAfterDiscount=amount!-(amount!*discrate!/100)
        //print(priceAfterDiscount)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //create a transition
        var transition=segue.identifier
        //create destination
        if(transition=="resultSegment")
        {
            //reach the destination
            var destination=segue.destination as! resultViewController
            destination.destinationAmount=amountOL.text!
            destination.destimationDiscRate=discrateOL.text!
            destination.destinationResult=String(priceAfterDiscount)
        }
    }
    
    
}

