//
//  resultViewController.swift
//  MultipleViewController
//
//  Created by Thukivakam,Sai Kiran on 3/30/23.
//

import UIKit

class resultViewController: UIViewController {
    
    
    @IBOutlet weak var displayamountOL: UILabel!
    
    @IBOutlet weak var discountOL: UILabel!
    
    @IBOutlet weak var outputOL: UILabel!
    
    //place to store the values
    var destinationAmount=""
    var destimationDiscRate=""
    var destinationResult=""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        displayamountOL.text=destinationAmount;
        discountOL.text=destimationDiscRate;
        outputOL.text=destinationResult
    }


}
