//
//  ViewController.swift
//  Discount
//
//  Created by Thukivakam,Sai Kiran on 2/14/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var originalPriceTextField: UITextField!
    
    
    @IBOutlet weak var discountedPriceTextField: UITextField!
    
    
    @IBOutlet weak var discountRateLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func Button(_ sender: Any) {
        if let originalPrice = Double(originalPriceTextField.text ?? ""),
               let discountedPrice = Double(discountedPriceTextField.text ?? "") {
                
                let discountRate = (originalPrice - discountedPrice) / originalPrice * 100.0
                discountRateLabel.text = "Discount rate is \(discountRate)%"
                
            } else {
                discountRateLabel.text = "Please enter valid prices"
            }
    }
}

