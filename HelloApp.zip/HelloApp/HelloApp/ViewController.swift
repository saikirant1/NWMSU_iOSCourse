//
//  ViewController.swift
//  HelloApp
//
//  Created by Thukivakam,Sai Kiran on 1/24/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputNameOutlet: UITextField!
    
    
    @IBOutlet weak var inputNameOutlet2: UITextField!
    
    @IBOutlet weak var displayLabelOutput: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClicked(_ sender: UIButton) {
        //read the input ans save it to the variable
        //assigning it to the variable
        var input = inputNameOutlet.text!
        var lname = inputNameOutlet2.text!
        //perform string interpolation (Hello, John
       //! ) and assign it to the display label
        displayLabelOutput.text = "Hello, \(input) \(lname) !"
    }
    
}
    


