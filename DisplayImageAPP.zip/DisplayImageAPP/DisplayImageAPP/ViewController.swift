//
//  ViewController.swift
//  DisplayImageAPP
//
//  Created by Thukivakam,Sai Kiran on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayImageOL: UIImageView!
    
    @IBOutlet weak var descriptionOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonClick(_ sender: Any) {
        
        descriptionOL.text="This is an image of Northwest Missouri State University located at Maryville, Missouri"
        displayImageOL.image=UIImage(named:"north")
        
    }
    
}

